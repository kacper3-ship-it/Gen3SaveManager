package com.example.gen3saves

import android.net.Uri
import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val fireRed = lightColorScheme(
                primary = androidx.compose.ui.graphics.Color(0xFFD9473F),
                onPrimary = androidx.compose.ui.graphics.Color(0xFFFFFFFF),
                primaryContainer = androidx.compose.ui.graphics.Color(0xFFFFDAD5),
                onPrimaryContainer = androidx.compose.ui.graphics.Color(0xFF410006),
                secondary = androidx.compose.ui.graphics.Color(0xFF356B8C),
                onSecondary = androidx.compose.ui.graphics.Color(0xFFFFFFFF),
                secondaryContainer = androidx.compose.ui.graphics.Color(0xFFD1E8FF),
                onSecondaryContainer = androidx.compose.ui.graphics.Color(0xFF001E2E),
                tertiary = androidx.compose.ui.graphics.Color(0xFFB77918),
                background = androidx.compose.ui.graphics.Color(0xFFFFF7EF),
                onBackground = androidx.compose.ui.graphics.Color(0xFF28201D),
                surface = androidx.compose.ui.graphics.Color(0xFFFFFCF8),
                onSurface = androidx.compose.ui.graphics.Color(0xFF28201D),
                surfaceVariant = androidx.compose.ui.graphics.Color(0xFFF2E4DC),
                onSurfaceVariant = androidx.compose.ui.graphics.Color(0xFF514541),
                outline = androidx.compose.ui.graphics.Color(0xFF89766D)
            )
            MaterialTheme(colorScheme = fireRed) {
                Surface(color = MaterialTheme.colorScheme.background) { App() }
            }
        }
    }
}

private fun dir(ctx: android.content.Context) = File(ctx.filesDir, "saves").apply { mkdirs() }

@Composable
fun App() {
    var open by remember { mutableStateOf<File?>(null) }
    val f = open
    if (f == null) ListScreen { open = it } else {
        BackHandler { open = null }
        Editor(f) { open = null }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ListScreen(onOpen: (File) -> Unit) {
    val ctx = LocalContext.current
    fun load() = dir(ctx).listFiles()?.filter { it.isFile && it.extension == "sav" }?.sortedByDescending { it.lastModified() } ?: emptyList()
    var files by remember { mutableStateOf(load()) }
    var pendingExport by remember { mutableStateOf<File?>(null) }
    var renaming by remember { mutableStateOf<File?>(null) }
    fun refresh() { files = load() }
    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_LONG).show()

    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri ?: return@rememberLauncherForActivityResult
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return@rememberLauncherForActivityResult
        val info = Save.open(bytes)?.info()
        if (info == null) { toast("Not a valid Gen 3 save (.sav, 128KB)"); return@rememberLauncherForActivityResult }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        File(dir(ctx), "${info.name.ifBlank { "SAVE" }}_${info.game.take(3).trim()}_$stamp.sav").writeBytes(bytes)
        refresh()
    }
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri: Uri? ->
        val f = pendingExport
        if (uri != null && f != null) {
            ctx.contentResolver.openOutputStream(uri)?.use { it.write(f.readBytes()) }
            toast("Exported")
        }
        pendingExport = null
    }

    Scaffold(
        topBar = { TopAppBar(
            title = { Column {
                Text("POKÉMON FIRE RED", style = MaterialTheme.typography.titleLarge)
                Text("GEN III SAVE MANAGER", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = { importer.launch(arrayOf("*/*")) }, icon = { Icon(Icons.Default.Add, null) }, text = { Text("Import .sav") })
        }
    ) { pad ->
        if (files.isEmpty()) {
            Box(Modifier.padding(pad).fillMaxSize(), Alignment.Center) { Text("No saves yet. Import a .sav from Ruby, Sapphire, Emerald, FireRed or LeafGreen.") }
        } else LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(files, key = { it.name }) { f ->
                val info = remember(f.lastModified(), f.name) { Save.open(f.readBytes())?.info() }
                Card(
                    Modifier.fillMaxWidth().clickable { if (info != null) onOpen(f) else toast("Unreadable save") },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Text(info?.game ?: "Unreadable", style = MaterialTheme.typography.labelLarge)
                        Text(info?.name ?: f.name, style = MaterialTheme.typography.headlineSmall)
                        if (info != null) {
                            Text("ID %05d / SID %05d · ${info.gender}".format(info.tid, info.sid))
                            Text("Play time ${info.playTime} · ₽${info.money}")
                            Text("Slot ${info.slot} · save #${info.saveCount}" + if (info.badSections > 0) " · ⚠ ${info.badSections} bad checksums" else " · checksums OK")
                        }
                        Text(f.name, style = MaterialTheme.typography.bodySmall)
                        Row {
                            IconButton({ onOpen(f) }) { Icon(Icons.Default.Visibility, "Open") }
                            IconButton({ pendingExport = f; exporter.launch(f.name) }) { Icon(Icons.Default.Share, "Export") }
                            IconButton({ f.copyTo(File(f.parentFile, "copy_${System.currentTimeMillis()}_${f.name}")); refresh() }) { Icon(Icons.Default.ContentCopy, "Duplicate") }
                            IconButton({ renaming = f }) { Icon(Icons.Default.Edit, "Rename") }
                            IconButton({ f.delete(); refresh() }) { Icon(Icons.Default.Delete, "Delete") }
                        }
                    }
                }
            }
        }
    }

    renaming?.let { f ->
        var text by remember { mutableStateOf(f.nameWithoutExtension) }
        AlertDialog(onDismissRequest = { renaming = null },
            title = { Text("Rename save") },
            text = { OutlinedTextField(text, { text = it }, singleLine = true) },
            confirmButton = { TextButton({ f.renameTo(File(f.parentFile, text.trim().replace('/', '_') + ".sav")); renaming = null; refresh() }) { Text("OK") } },
            dismissButton = { TextButton({ renaming = null }) { Text("Cancel") } })
    }
}

@Composable
fun NumField(label: String, value: String, modifier: Modifier = Modifier, onChange: (String) -> Unit) =
    OutlinedTextField(value, { onChange(it.filter(Char::isDigit).take(7)) }, label = { Text(label) }, singleLine = true,
        modifier = modifier, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Editor(file: File, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val save = remember(file) { Save.open(file.readBytes()) }
    if (save == null) { Text("Unreadable save"); return }
    var tab by remember { mutableStateOf(0) }
    var ver by remember { mutableStateOf(0) }
    var box by remember { mutableStateOf(save.currentBox.coerceIn(0, 13)) }
    var boxSearch by remember { mutableStateOf("") }
    var searchAllBoxes by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf<Triple<Boolean, Int, Int>?>(null) }
    var createSlot by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    var itemEdit by remember { mutableStateOf<Pair<Pocket, Int>?>(null) }
    var choosingBagItem by remember { mutableStateOf(false) }

    LaunchedEffect(file) { // keep the untouched original the first time a save is opened
        val dest = File(File(ctx.filesDir, "backups").apply { mkdirs() }, file.name + ".orig")
        if (!dest.exists()) file.copyTo(dest)
    }
    fun commit() { save.fixChecksums(); file.writeBytes(save.data); ver++ }

    Scaffold(topBar = {
        TopAppBar(
            title = { Column {
                Text(save.info().name.ifBlank { "Save" } )
                Text(save.gameName.uppercase(Locale.ROOT), style = MaterialTheme.typography.labelSmall)
            } },
            navigationIcon = { IconButton(onBack) { Icon(Icons.Default.ArrowBack, "Back") } },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        )
    }) { pad ->
        Column(Modifier.padding(pad)) {
            TabRow(
                selectedTabIndex = tab,
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                contentColor = MaterialTheme.colorScheme.primary
            ) {
                listOf("Trainer", "Party", "Boxes", "Bag", "Dex").forEachIndexed { i, t -> Tab(tab == i, { tab = i }) { Text(t, Modifier.padding(14.dp)) } }
            }
            key(ver) {
                when (tab) {
                    0 -> {
                        val i = save.info()
                        var m by remember { mutableStateOf(i.money.toString()) }
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("${i.name} (${i.gender})", style = MaterialTheme.typography.headlineSmall)
                            Text("ID %05d / SID %05d".format(i.tid, i.sid))
                            Text("Play time ${i.playTime}")
                            Text("Slot ${i.slot} · save #${i.saveCount} · " + if (i.badSections > 0) "⚠ ${i.badSections} bad checksums" else "checksums OK")
                            NumField("Money", m) { m = it }
                            Button({ save.money = (m.toLongOrNull() ?: 0L).coerceIn(0, 999999); commit() }) { Text("Save money") }
                            Text("An untouched copy of the original is kept the first time you open a save.", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    1 -> LazyColumn {
                        items(save.partyCount) { i -> MonRow(Mon(save.getParty(i)), true) { edit = Triple(true, 0, i) } }
                    }
                    2 -> Column(Modifier.fillMaxSize()) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            IconButton({ box = (box + 13) % 14 }) { Icon(Icons.Default.ChevronLeft, "Previous box") }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(save.boxName(box), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                                Text("BOX ${box + 1} / 14", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            IconButton({ box = (box + 1) % 14 }) { Icon(Icons.Default.ChevronRight, "Next box") }
                        }
                        OutlinedTextField(
                            value = boxSearch,
                            onValueChange = { boxSearch = it },
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                            singleLine = true,
                            label = { Text("Search this box by species or nickname") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                            trailingIcon = { if (boxSearch.isNotBlank()) IconButton(onClick = { boxSearch = "" }) { Icon(Icons.Default.Clear, contentDescription = "Clear search") } }
                        )
                        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = searchAllBoxes, onCheckedChange = { searchAllBoxes = it })
                            Text("Search all 14 boxes", style = MaterialTheme.typography.bodySmall)
                        }
                        val searchBoxes = if (searchAllBoxes && boxSearch.isNotBlank()) (0 until 14).toList() else listOf(box)
                        val visibleSlots = searchBoxes.flatMap { b -> (0 until 30).map { slot -> b to slot } }.filter { (b, slot) ->
                            if (boxSearch.isBlank()) b == box else {
                                val candidate = Mon(save.getBox(b, slot))
                                candidate.species != 0 && (speciesName(candidate.species).contains(boxSearch, true) || candidate.nick.contains(boxSearch, true))
                            }
                        }
                        val boxOccupied = (0 until 30).map { Mon(save.getBox(box, it)) }.filter { it.species != 0 }
                        val shinyCount = boxOccupied.count { it.shiny }
                        Text("${visibleSlots.size} ${if (boxSearch.isBlank()) "slots" else "matches"}  ·  ${boxOccupied.size}/30 occupied  ·  ★ $shinyCount", Modifier.padding(start = 16.dp, bottom = 3.dp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Card(Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer), shape = MaterialTheme.shapes.large) {
                            LazyVerticalGrid(columns = GridCells.Fixed(5), modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                items(visibleSlots) { (slotBox, i) ->
                                    val m = remember(ver, slotBox, i) { Mon(save.getBox(slotBox, i)) }
                                    val occupied = m.species != 0
                                    Card(Modifier.fillMaxWidth().height(88.dp).clickable { box = slotBox; if (occupied) edit = Triple(false, slotBox, i) else createSlot = slotBox to i },
                                        colors = CardDefaults.cardColors(containerColor = if (occupied) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surface.copy(alpha = 0.58f)),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, if (occupied && m.shiny) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)), shape = MaterialTheme.shapes.medium) {
                                        Column(Modifier.fillMaxSize().padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                            if (occupied && !m.isEgg) PokemonSprite(m.species, Modifier.size(38.dp))
                                            else Text(if (occupied) "🥚" else "＋", style = MaterialTheme.typography.titleLarge, color = if (occupied && m.shiny) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.primary)
                                            Text(if (!occupied) "Empty" else if (m.isEgg) "Egg" else speciesName(m.species), style = MaterialTheme.typography.labelSmall, maxLines = 1)
                                            if (occupied) Text(if (m.shiny) "★ Shiny" else " ", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.tertiary, maxLines = 1)
                                            else Text("%02d".format(i + 1), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            if (searchAllBoxes && boxSearch.isNotBlank() && occupied) Text("BOX ${slotBox + 1}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    3 -> LazyColumn {
                        for (p in save.layout.pockets) {
                            item { Text(p.name, Modifier.padding(12.dp), style = MaterialTheme.typography.titleMedium) }
                            items(p.n) { i ->
                                val (id, q) = save.getItem(p, i)
                                Text(if (id == 0) "(empty)" else "${itemName(id)} × $q",
                                    Modifier.fillMaxWidth().clickable { itemEdit = p to i }.padding(horizontal = 16.dp, vertical = 10.dp))
                            }
                        }
                    }
                    4 -> {
                        if (save.game != 1) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Pokédex editing is currently enabled for FireRed / LeafGreen saves.") }
                        } else DexEditor(save, ::commit)
                    }
                }
            }
        }
    }

    edit?.let { (party, b, i) -> MonEditor(save, party, b, i, { edit = null }) { commit(); edit = null } }
    createSlot?.let { (b, i) ->
        var species by remember { mutableStateOf("1") }
        var nickname by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { createSlot = null },
            title = { Text("Create Pokémon · ${save.boxName(b)}") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                NumField("Species number (1–386)", species) { species = it }
                OutlinedTextField(nickname, { nickname = it.take(10) }, label = { Text("Nickname (optional)") }, singleLine = true)
                Text("Creates a basic boxed Pokémon record with default data. Complete its details in the editor before using it in-game.", style = MaterialTheme.typography.bodySmall)
            } },
            confirmButton = { TextButton(onClick = {
                val id = species.toIntOrNull() ?: 0
                if (id in 1..386) {
                    val fresh = Mon(ByteArray(80)); fresh.species = id; fresh.nick = nickname.ifBlank { speciesName(id) }
                    save.setBox(b, i, fresh.toRaw()); commit(); createSlot = null
                } else Toast.makeText(ctx, "Enter a valid species number", Toast.LENGTH_SHORT).show()
            }) { Text("Create") } },
            dismissButton = { TextButton({ createSlot = null }) { Text("Cancel") } })
    }
    itemEdit?.let { (p, i) ->
        val (id0, q0) = save.getItem(p, i)
        var id by remember { mutableStateOf(id0.toString()) }
        var q by remember { mutableStateOf(q0.toString()) }
        AlertDialog(onDismissRequest = { itemEdit = null },
            title = { Text(p.name) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { choosingBagItem = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("Item: ${itemName(id.toIntOrNull() ?: 0)}")
                    }
                    NumField("Quantity", q) { q = it }
                }
            },
            confirmButton = {
                TextButton({
                    val n = (id.toIntOrNull() ?: 0).coerceIn(0, 376)
                    save.setItem(p, i, n, if (n == 0) 0 else (q.toIntOrNull() ?: 1).coerceIn(1, 999))
                    commit(); itemEdit = null
                }) { Text("Save") }
            },
            dismissButton = { TextButton({ itemEdit = null }) { Text("Cancel") } })
        if (choosingBagItem) ItemPicker(id.toIntOrNull() ?: 0,
            onSelect = { id = it.toString(); choosingBagItem = false },
            onDismiss = { choosingBagItem = false })
    }
}

@Composable
fun DexEditor(save: Save, onSave: () -> Unit) {
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("All") }
    val speciesIds = remember { (1..251).toList() + (277..411).toList() }
    val filtered = speciesIds.filter { id ->
        val seen = save.dexSeen(id); val caught = save.dexCaught(id)
        val matches = speciesName(id).contains(query, true) || id.toString().contains(query)
        matches && when (filter) { "Caught" -> caught; "Seen" -> seen && !caught; "Unseen" -> !seen && !caught; else -> true }
    }
    val caughtCount = speciesIds.count { save.dexCaught(it) }
    val seenCount = speciesIds.count { save.dexSeen(it) }
    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        Text("Kanto + National Pokédex", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 10.dp))
        Text("$caughtCount caught · $seenCount seen · 386 species", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), singleLine = true, label = { Text("Search species") }, leadingIcon = { Icon(Icons.Default.Search, null) })
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf("All", "Caught", "Seen", "Unseen").forEach { option ->
                FilterChip(selected = filter == option, onClick = { filter = option }, label = { Text(option) })
            }
        }
        LazyColumn(Modifier.weight(1f)) {
            items(filtered) { id ->
                val seen = save.dexSeen(id); val caught = save.dexCaught(id)
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("#${if (id <= 251) id else id - 25}  ${speciesName(id)}", style = MaterialTheme.typography.titleSmall)
                        Text(if (caught) "Caught" else if (seen) "Seen" else "Not registered", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Checkbox(checked = seen, onCheckedChange = { checked -> save.setDexFlags(id, checked, caught && checked); onSave() })
                    Text("Seen", style = MaterialTheme.typography.labelSmall)
                    Checkbox(checked = caught, onCheckedChange = { checked -> save.setDexFlags(id, seen || checked, checked); onSave() })
                    Text("Own", style = MaterialTheme.typography.labelSmall)
                }
                Divider()
            }
        }
    }
}

@Composable
fun ItemPicker(selected: Int, onSelect: (Int) -> Unit, onDismiss: () -> Unit) {
    val choices = remember {
        allItemChoices()
    }
    var search by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss,
        title = { Text("Choose item") },
        text = {
            Column {
                OutlinedTextField(search, { search = it }, label = { Text("Search items") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                LazyColumn(Modifier.heightIn(max = 420.dp)) {
                    items(choices.filter { it.second.contains(search, ignoreCase = true) }) { (id, name) ->
                        Text(name + if (id == selected) " ✓" else "",
                            Modifier.fillMaxWidth().clickable { onSelect(id) }.padding(12.dp))
                    }
                }
            }
        },
        confirmButton = { TextButton(onDismiss) { Text("Cancel") } })
}

@Composable
fun PokemonSprite(species: Int, modifier: Modifier = Modifier) {
    val national = if (species in 277..411) species - 25 else species
    val bitmap by produceState<android.graphics.Bitmap?>(initialValue = null, key1 = national) {
        value = if (national in 1..386) withContext(Dispatchers.IO) {
            try {
                val connection = java.net.URL("https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/$national.png").openConnection()
                connection.connectTimeout = 4000
                connection.readTimeout = 4000
                connection.getInputStream().use { BitmapFactory.decodeStream(it) }
            } catch (_: Exception) { null }
        } else null
    }
    if (bitmap != null) Image(bitmap!!.asImageBitmap(), contentDescription = speciesName(species), modifier = modifier)
    else Box(modifier, contentAlignment = Alignment.Center) { Text("🔴", style = MaterialTheme.typography.titleLarge) }
}

@Composable
fun MonRow(m: Mon, party: Boolean, onClick: () -> Unit) {
    val name = if (m.isEgg) "Egg" else speciesName(m.species)
    val nick = if (m.nick.isNotBlank() && !m.nick.equals(name, true) && !m.isEgg) "${m.nick} ($name)" else name
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        if (!m.isEgg && m.species != 0) PokemonSprite(m.species, Modifier.size(48.dp))
        Column(Modifier.weight(1f).padding(start = 8.dp)) {
            Text(nick + (if (m.shiny) " ★" else "") + (if (party) "  Lv ${m.level}" else ""), style = MaterialTheme.typography.titleSmall)
            Text("${m.nature} · " + (0..3).map { m.move(it) }.filter { it != 0 }.joinToString(", ") { moveName(it) }, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun MonEditor(save: Save, party: Boolean, box: Int, idx: Int, onClose: () -> Unit, onSaved: () -> Unit) {
    val ctx = LocalContext.current
    val mon = remember { Mon(if (party) save.getParty(idx) else save.getBox(box, idx)) }
    val v = remember {
        mutableStateListOf(mon.species.toString(), mon.item.toString(),
            *Array(4) { mon.move(it).toString() }, *Array(6) { mon.iv(it).toString() }, *Array(6) { mon.ev(it).toString() })
    }
    var choosingHeldItem by remember { mutableStateOf(false) }
    var releaseConfirm by remember { mutableStateOf(false) }
    var movePicker by remember { mutableStateOf(false) }
    var nickname by remember { mutableStateOf(mon.nick) }
    var selectedNature by remember { mutableStateOf(mon.nature) }
    var selectedAbilitySlot by remember { mutableStateOf(mon.abilitySlot) }
    var transferMessage by remember { mutableStateOf("") }
    val exportMon = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) ctx.contentResolver.openOutputStream(uri)?.use { it.write(mon.toRaw().copyOfRange(0, 80)) }
        transferMessage = if (uri != null) "Exported Pokémon (.pk3)" else "Export cancelled"
    }
    val importMon = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            if (bytes != null && bytes.size == 80) {
                val incoming = Mon(bytes)
                if (incoming.species in 1..386 && incoming.checksumValid && !party) {
                    save.setBox(box, idx, incoming.toRaw())
                    save.fixChecksums(); transferMessage = "Imported ${speciesName(incoming.species)}"; onSaved()
                } else transferMessage = if (party) "Import .pk3 into a PC box first, then withdraw it to the party" else "That file doesn't contain a valid Gen III Pokémon"
            } else transferMessage = "Choose an 80-byte Gen III .pk3 file"
        }
    }
    val stats = listOf("HP", "Atk", "Def", "Spe", "SpA", "SpD")
    fun n(i: Int, max: Int) = (v[i].toIntOrNull() ?: 0).coerceIn(0, max)
    fun apply() {
        if (!mon.setNatureAndAbility(selectedNature, selectedAbilitySlot)) {
            Toast.makeText(ctx, "Could not safely find a matching personality value", Toast.LENGTH_LONG).show()
            return
        }
        mon.nick = nickname
        val s = n(0, 411)
        if (s in 1..251 || s in 277..411) mon.species = s
        mon.item = n(1, 376)
        for (k in 0..3) { val m = n(2 + k, 354); if (m != mon.move(k)) mon.setMove(k, m) }
        for (k in 0..5) { mon.setIv(k, n(6 + k, 31)); mon.setEv(k, n(12 + k, 255)) }
        val out = mon.toRaw()
        if (party) save.setParty(idx, out) else save.setBox(box, idx, out)
        onSaved()
    }
    AlertDialog(onDismissRequest = onClose,
        title = { Text((if (mon.isEgg) "Egg" else mon.nick.ifBlank { speciesName(mon.species) }) + " · ${mon.nature}" + if (mon.shiny) " ★" else "") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(nickname, { nickname = it.take(10) }, label = { Text("Nickname (10 characters max)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Text("Personality", style = MaterialTheme.typography.titleSmall)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = {
                        val all = listOf("Hardy", "Lonely", "Brave", "Adamant", "Naughty", "Bold", "Docile", "Relaxed", "Impish", "Lax", "Timid", "Hasty", "Serious", "Jolly", "Naive", "Modest", "Mild", "Quiet", "Bashful", "Rash", "Calm", "Gentle", "Sassy", "Careful", "Quirky")
                        selectedNature = all[(all.indexOf(selectedNature) + 1) % all.size]
                    }, modifier = Modifier.weight(1f)) { Text("Nature: $selectedNature") }
                    OutlinedButton(onClick = { selectedAbilitySlot = 1 - selectedAbilitySlot }, modifier = Modifier.weight(1f)) { Text("Ability slot ${selectedAbilitySlot + 1}") }
                }
                Text("Changing nature or ability slot adjusts the personality value. This can affect gender-dependent traits; shiny status is preserved.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                NumField("Species: " + speciesName(v[0].toIntOrNull() ?: 0), v[0], Modifier.fillMaxWidth()) { v[0] = it }
                OutlinedButton(onClick = { choosingHeldItem = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Held item: ${itemName(v[1].toIntOrNull() ?: 0)}")
                }
                for (k in 0..3) NumField("Move ${k + 1}: " + moveName(v[2 + k].toIntOrNull() ?: 0), v[2 + k], Modifier.fillMaxWidth()) { v[2 + k] = it }
                Text("IVs (0-31)")
                for (r in 0..1) Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (c in 0..2) NumField(stats[r * 3 + c], v[6 + r * 3 + c], Modifier.weight(1f)) { v[6 + r * 3 + c] = it }
                }
                TextButton({ for (k in 6..11) v[k] = "31" }) { Text("Max all IVs") }
                Text("EVs (0-255, game caps total at 510)")
                for (r in 0..1) Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (c in 0..2) NumField(stats[r * 3 + c], v[12 + r * 3 + c], Modifier.weight(1f)) { v[12 + r * 3 + c] = it }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { exportMon.launch((mon.nick.ifBlank { speciesName(mon.species) }.replace(" ", "_") + ".pk3")) }, modifier = Modifier.weight(1f)) { Text("Export .pk3") }
                    if (!party) OutlinedButton(onClick = { importMon.launch(arrayOf("*/*")) }, modifier = Modifier.weight(1f)) { Text("Import .pk3") }
                }
                if (transferMessage.isNotBlank()) Text(transferMessage, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                if (party) Text("Party stats refresh after a level-up or a box deposit/withdraw.", style = MaterialTheme.typography.bodySmall)
                if (!party) {
                    Divider()
                    Text("PC box actions", style = MaterialTheme.typography.titleSmall)
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = {
                                val target = (0 until 30).firstOrNull { Mon(save.getBox(box, it)).species == 0 }
                                if (target == null) Toast.makeText(ctx, "This box is full", Toast.LENGTH_SHORT).show()
                                else {
                                    save.setBox(box, target, mon.toRaw())
                                    save.fixChecksums()
                                    Toast.makeText(ctx, "Copied to slot ${target + 1}", Toast.LENGTH_SHORT).show()
                                    onSaved()
                                }
                            }, modifier = Modifier.weight(1f)) { Text("Duplicate") }
                            OutlinedButton(onClick = { movePicker = true }, modifier = Modifier.weight(1f)) { Text("Move box") }
                        }
                        OutlinedButton(onClick = { releaseConfirm = true }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)) { Text("Release Pokémon") }
                    }
                }
            }
        },
        confirmButton = { TextButton({ apply() }) { Text("Save") } },
        dismissButton = { TextButton(onClose) { Text("Cancel") } })
    if (releaseConfirm) AlertDialog(
        onDismissRequest = { releaseConfirm = false },
        title = { Text("Release Pokémon?") },
        text = { Text("This clears this PC slot. Make sure you have a backup before releasing it.") },
        confirmButton = { TextButton(onClick = {
            save.setBox(box, idx, ByteArray(80))
            save.fixChecksums()
            releaseConfirm = false
            onSaved()
        }, colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)) { Text("Release") } },
        dismissButton = { TextButton(onClick = { releaseConfirm = false }) { Text("Cancel") } }
    )
    if (movePicker) AlertDialog(
        onDismissRequest = { movePicker = false },
        title = { Text("Move to which box?") },
        text = {
            LazyColumn(Modifier.heightIn(max = 420.dp)) {
                items((0 until 14).filter { it != box }) { targetBox ->
                    Text("${save.boxName(targetBox)}  ·  BOX ${targetBox + 1}",
                        Modifier.fillMaxWidth().clickable {
                            val targetSlot = (0 until 30).firstOrNull { Mon(save.getBox(targetBox, it)).species == 0 }
                            if (targetSlot == null) {
                                Toast.makeText(ctx, "${save.boxName(targetBox)} is full", Toast.LENGTH_SHORT).show()
                            } else {
                                save.setBox(targetBox, targetSlot, mon.toRaw())
                                save.setBox(box, idx, ByteArray(80))
                                save.fixChecksums()
                                Toast.makeText(ctx, "Moved to ${save.boxName(targetBox)}", Toast.LENGTH_SHORT).show()
                                movePicker = false
                                onSaved()
                            }
                        }.padding(14.dp))
                }
            }
        },
        confirmButton = { TextButton({ movePicker = false }) { Text("Cancel") } }
    )
    if (choosingHeldItem) ItemPicker(v[1].toIntOrNull() ?: 0, onSelect = { v[1] = it.toString(); choosingHeldItem = false }, onDismiss = { choosingHeldItem = false })
}
