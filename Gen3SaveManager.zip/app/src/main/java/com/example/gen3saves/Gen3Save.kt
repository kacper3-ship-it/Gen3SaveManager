package com.example.gen3saves

data class SaveInfo(
    val game: String, val name: String, val gender: String, val tid: Int, val sid: Int,
    val playTime: String, val money: Long, val slot: Char, val saveCount: Long, val badSections: Int
)

/** Parser for Generation 3 (Ruby/Sapphire/Emerald/FireRed/LeafGreen) 128KB saves. */
object Gen3 {
    const val SIZE = 131072
    private const val SEC = 4096
    private const val SIGNATURE = 0x08012025L
    private val SECTION_SIZES = intArrayOf(3884, 3968, 3968, 3968, 3848, 3968, 3968, 3968, 3968, 3968, 3968, 3968, 3968, 2000)

    private fun u8(b: ByteArray, o: Int) = b[o].toInt() and 0xFF
    private fun u16(b: ByteArray, o: Int) = u8(b, o) or (u8(b, o + 1) shl 8)
    private fun u32(b: ByteArray, o: Int) = (u16(b, o).toLong()) or (u16(b, o + 2).toLong() shl 16)

    private fun checksum(b: ByteArray, off: Int, len: Int): Int {
        var sum = 0L
        for (i in 0 until len step 4) sum = (sum + u32(b, off + i)) and 0xFFFFFFFFL
        return (((sum shr 16) + (sum and 0xFFFF)) and 0xFFFF).toInt()
    }

    private fun decodeText(b: ByteArray, off: Int, max: Int): String {
        val sb = StringBuilder()
        for (i in 0 until max) {
            val c = u8(b, off + i)
            when (c) {
                0xFF -> break
                0x00 -> sb.append(' ')
                in 0xA1..0xAA -> sb.append('0' + (c - 0xA1))
                in 0xBB..0xD4 -> sb.append('A' + (c - 0xBB))
                in 0xD5..0xEE -> sb.append('a' + (c - 0xD5))
                0xAB -> sb.append('!'); 0xAC -> sb.append('?'); 0xAD -> sb.append('.'); 0xAE -> sb.append('-')
                else -> sb.append('?')
            }
        }
        return sb.toString()
    }

    /** Returns null if the data is not a valid Gen 3 save. */
    fun parse(data: ByteArray): SaveInfo? {
        if (data.size < SIZE) return null
        var best = -1; var bestIdx = -1L; var bestSlot = 0
        val offsets = Array(2) { IntArray(14) { -1 } }
        val idx = LongArray(2) { -1 }
        for (slot in 0..1) for (s in 0 until 14) {
            val o = slot * 14 * SEC + s * SEC
            if (u32(data, o + 0xFF8) != SIGNATURE) continue
            val id = u16(data, o + 0xFF4)
            if (id > 13) continue
            offsets[slot][id] = o
            idx[slot] = maxOf(idx[slot], u32(data, o + 0xFFC))
        }
        for (slot in 0..1) if (idx[slot] > bestIdx && offsets[slot].all { it >= 0 }) { bestIdx = idx[slot]; bestSlot = slot; best = slot }
        if (best < 0) return null
        val o = offsets[best]
        val bad = (0 until 14).count { checksum(data, o[it], SECTION_SIZES[it]) != u16(data, o[it] + 0xFF6) }
        val t = o[0]; val team = o[1]
        val code = u32(data, t + 0xAC)
        val (game, moneyOff, key) = when (code) {
            0L -> Triple("Ruby / Sapphire", 0x490, 0L)
            1L -> Triple("FireRed / LeafGreen", 0x290, u32(data, t + 0xAF8))
            else -> Triple("Emerald", 0x490, code)
        }
        val money = u32(data, team + moneyOff) xor key
        val time = "${u16(data, t + 0x0E)}:%02d:%02d".format(u8(data, t + 0x10), u8(data, t + 0x11))
        return SaveInfo(
            game, decodeText(data, t, 7), if (u8(data, t + 8) == 0) "Boy" else "Girl",
            u16(data, t + 0x0A), u16(data, t + 0x0C), time, money and 0xFFFFFFFFL,
            if (bestSlot == 0) 'A' else 'B', bestIdx, bad
        )
    }
}
