package com.example.gen3saves

private const val G1 = "Bulbasaur,Ivysaur,Venusaur,Charmander,Charmeleon,Charizard,Squirtle,Wartortle,Blastoise,Caterpie,Metapod,Butterfree,Weedle,Kakuna,Beedrill,Pidgey,Pidgeotto,Pidgeot,Rattata,Raticate,Spearow,Fearow,Ekans,Arbok,Pikachu,Raichu,Sandshrew,Sandslash,Nidoran F,Nidorina,Nidoqueen,Nidoran M,Nidorino,Nidoking,Clefairy,Clefable,Vulpix,Ninetales,Jigglypuff,Wigglytuff,Zubat,Golbat,Oddish,Gloom,Vileplume,Paras,Parasect,Venonat,Venomoth,Diglett,Dugtrio,Meowth,Persian,Psyduck,Golduck,Mankey,Primeape,Growlithe,Arcanine,Poliwag,Poliwhirl,Poliwrath,Abra,Kadabra,Alakazam,Machop,Machoke,Machamp,Bellsprout,Weepinbell,Victreebel,Tentacool,Tentacruel,Geodude,Graveler,Golem,Ponyta,Rapidash,Slowpoke,Slowbro,Magnemite,Magneton,Farfetch'd,Doduo,Dodrio,Seel,Dewgong,Grimer,Muk,Shellder,Cloyster,Gastly,Haunter,Gengar,Onix,Drowzee,Hypno,Krabby,Kingler,Voltorb,Electrode,Exeggcute,Exeggutor,Cubone,Marowak,Hitmonlee,Hitmonchan,Lickitung,Koffing,Weezing,Rhyhorn,Rhydon,Chansey,Tangela,Kangaskhan,Horsea,Seadra,Goldeen,Seaking,Staryu,Starmie,Mr. Mime,Scyther,Jynx,Electabuzz,Magmar,Pinsir,Tauros,Magikarp,Gyarados,Lapras,Ditto,Eevee,Vaporeon,Jolteon,Flareon,Porygon,Omanyte,Omastar,Kabuto,Kabutops,Aerodactyl,Snorlax,Articuno,Zapdos,Moltres,Dratini,Dragonair,Dragonite,Mewtwo,Mew"
private const val G2 = "Chikorita,Bayleef,Meganium,Cyndaquil,Quilava,Typhlosion,Totodile,Croconaw,Feraligatr,Sentret,Furret,Hoothoot,Noctowl,Ledyba,Ledian,Spinarak,Ariados,Crobat,Chinchou,Lanturn,Pichu,Cleffa,Igglybuff,Togepi,Togetic,Natu,Xatu,Mareep,Flaaffy,Ampharos,Bellossom,Marill,Azumarill,Sudowoodo,Politoed,Hoppip,Skiploom,Jumpluff,Aipom,Sunkern,Sunflora,Yanma,Wooper,Quagsire,Espeon,Umbreon,Murkrow,Slowking,Misdreavus,Unown,Wobbuffet,Girafarig,Pineco,Forretress,Dunsparce,Gligar,Steelix,Snubbull,Granbull,Qwilfish,Scizor,Shuckle,Heracross,Sneasel,Teddiursa,Ursaring,Slugma,Magcargo,Swinub,Piloswine,Corsola,Remoraid,Octillery,Delibird,Mantine,Skarmory,Houndour,Houndoom,Kingdra,Phanpy,Donphan,Porygon2,Stantler,Smeargle,Tyrogue,Hitmontop,Smoochum,Elekid,Magby,Miltank,Blissey,Raikou,Entei,Suicune,Larvitar,Pupitar,Tyranitar,Lugia,Ho-Oh,Celebi"
private const val HOENN = "Treecko,Grovyle,Sceptile,Torchic,Combusken,Blaziken,Mudkip,Marshtomp,Swampert,Poochyena,Mightyena,Zigzagoon,Linoone,Wurmple,Silcoon,Beautifly,Cascoon,Dustox,Lotad,Lombre,Ludicolo,Seedot,Nuzleaf,Shiftry,Nincada,Ninjask,Shedinja,Taillow,Swellow,Shroomish,Breloom,Spinda,Wingull,Pelipper,Surskit,Masquerain,Wailmer,Wailord,Skitty,Delcatty,Kecleon,Baltoy,Claydol,Nosepass,Torkoal,Sableye,Barboach,Whiscash,Luvdisc,Corphish,Crawdaunt,Feebas,Milotic,Carvanha,Sharpedo,Trapinch,Vibrava,Flygon,Makuhita,Hariyama,Electrike,Manectric,Numel,Camerupt,Spheal,Sealeo,Walrein,Cacnea,Cacturne,Snorunt,Glalie,Lunatone,Solrock,Azurill,Spoink,Grumpig,Plusle,Minun,Mawile,Meditite,Medicham,Swablu,Altaria,Wynaut,Duskull,Dusclops,Roselia,Slakoth,Vigoroth,Slaking,Gulpin,Swalot,Tropius,Whismur,Loudred,Exploud,Clamperl,Huntail,Gorebyss,Absol,Shuppet,Banette,Seviper,Zangoose,Relicanth,Aron,Lairon,Aggron,Castform,Volbeat,Illumise,Lileep,Cradily,Anorith,Armaldo,Ralts,Kirlia,Gardevoir,Bagon,Shelgon,Salamence,Beldum,Metang,Metagross,Regirock,Regice,Registeel,Kyogre,Groudon,Rayquaza,Latias,Latios,Jirachi,Deoxys,Chimecho"
private const val MV = "Pound,Karate Chop,Double Slap,Comet Punch,Mega Punch,Pay Day,Fire Punch,Ice Punch,Thunder Punch,Scratch,Vice Grip,Guillotine,Razor Wind,Swords Dance,Cut,Gust,Wing Attack,Whirlwind,Fly,Bind,Slam,Vine Whip,Stomp,Double Kick,Mega Kick,Jump Kick,Rolling Kick,Sand-Attack,Headbutt,Horn Attack,Fury Attack,Horn Drill,Tackle,Body Slam,Wrap,Take Down,Thrash,Double-Edge,Tail Whip,Poison Sting,Twineedle,Pin Missile,Leer,Bite,Growl,Roar,Sing,Supersonic,Sonic Boom,Disable,Acid,Ember,Flamethrower,Mist,Water Gun,Hydro Pump,Surf,Ice Beam,Blizzard,Psybeam,Bubble Beam,Aurora Beam,Hyper Beam,Peck,Drill Peck,Submission,Low Kick,Counter,Seismic Toss,Strength,Absorb,Mega Drain,Leech Seed,Growth,Razor Leaf,Solar Beam,Poison Powder,Stun Spore,Sleep Powder,Petal Dance,String Shot,Dragon Rage,Fire Spin,Thunder Shock,Thunderbolt,Thunder Wave,Thunder,Rock Throw,Earthquake,Fissure,Dig,Toxic,Confusion,Psychic,Hypnosis,Meditate,Agility,Quick Attack,Rage,Teleport,Night Shade,Mimic,Screech,Double Team,Recover,Harden,Minimize,Smokescreen,Confuse Ray,Withdraw,Defense Curl,Barrier,Light Screen,Haze,Reflect,Focus Energy,Bide,Metronome,Mirror Move,Self-Destruct,Egg Bomb,Lick,Smog,Sludge,Bone Club,Fire Blast,Waterfall,Clamp,Swift,Skull Bash,Spike Cannon,Constrict,Amnesia,Kinesis,Soft-Boiled,High Jump Kick,Glare,Dream Eater,Poison Gas,Barrage,Leech Life,Lovely Kiss,Sky Attack,Transform,Bubble,Dizzy Punch,Spore,Flash,Psywave,Splash,Acid Armor,Crabhammer,Explosion,Fury Swipes,Bonemerang,Rest,Rock Slide,Hyper Fang,Sharpen,Conversion,Tri Attack,Super Fang,Slash,Substitute,Struggle,Sketch,Triple Kick,Thief,Spider Web,Mind Reader,Nightmare,Flame Wheel,Snore,Curse,Flail,Conversion 2,Aeroblast,Cotton Spore,Reversal,Spite,Powder Snow,Protect,Mach Punch,Scary Face,Faint Attack,Sweet Kiss,Belly Drum,Sludge Bomb,Mud-Slap,Octazooka,Spikes,Zap Cannon,Foresight,Destiny Bond,Perish Song,Icy Wind,Detect,Bone Rush,Lock-On,Outrage,Sandstorm,Giga Drain,Endure,Charm,Rollout,False Swipe,Swagger,Milk Drink,Spark,Fury Cutter,Steel Wing,Mean Look,Attract,Sleep Talk,Heal Bell,Return,Present,Frustration,Safeguard,Pain Split,Sacred Fire,Magnitude,Dynamic Punch,Megahorn,Dragon Breath,Baton Pass,Encore,Pursuit,Rapid Spin,Sweet Scent,Iron Tail,Metal Claw,Vital Throw,Morning Sun,Synthesis,Moonlight,Hidden Power,Cross Chop,Twister,Rain Dance,Sunny Day,Crunch,Mirror Coat,Psych Up,Extreme Speed,Ancient Power,Shadow Ball,Future Sight,Rock Smash,Whirlpool,Beat Up,Fake Out,Uproar,Stockpile,Spit Up,Swallow,Heat Wave,Hail,Torment,Flatter,Will-O-Wisp,Memento,Facade,Focus Punch,Smelling Salt,Follow Me,Nature Power,Charge,Taunt,Helping Hand,Trick,Role Play,Wish,Assist,Ingrain,Superpower,Magic Coat,Recycle,Revenge,Brick Break,Yawn,Knock Off,Endeavor,Eruption,Skill Swap,Imprison,Refresh,Grudge,Snatch,Secret Power,Dive,Arm Thrust,Camouflage,Tail Glow,Luster Purge,Mist Ball,Feather Dance,Teeter Dance,Blaze Kick,Mud Sport,Ice Ball,Needle Arm,Slack Off,Hyper Voice,Poison Fang,Crush Claw,Blast Burn,Hydro Cannon,Meteor Mash,Astonish,Weather Ball,Aromatherapy,Fake Tears,Air Cutter,Overheat,Odor Sleuth,Rock Tomb,Silver Wind,Metal Sound,Grass Whistle,Tickle,Cosmic Power,Water Spout,Signal Beam,Shadow Punch,Extrasensory,Sky Uppercut,Sand Tomb,Sheer Cold,Muddy Water,Bullet Seed,Aerial Ace,Icicle Spear,Iron Defense,Block,Howl,Dragon Claw,Frenzy Plant,Bulk Up,Bounce,Mud Shot,Poison Tail,Covet,Volt Tackle,Magical Leaf,Water Sport,Calm Mind,Leaf Blade,Dragon Dance,Rock Blast,Shock Wave,Water Pulse,Doom Desire,Psycho Boost"
private val ITEM_DATA = """
1|Master Ball
2|Ultra Ball
3|Great Ball
4|Poké Ball
5|Safari Ball
6|Net Ball
7|Dive Ball
8|Nest Ball
9|Repeat Ball
10|Timer Ball
11|Luxury Ball
12|Premier Ball
13|Potion
14|Antidote
15|Burn Heal
16|Ice Heal
17|Awakening
18|Parlyz Heal
19|Full Restore
20|Max Potion
21|Hyper Potion
22|Super Potion
23|Full Heal
24|Revive
25|Max Revive
26|Fresh Water
27|Soda Pop
28|Lemonade
29|Moomoo Milk
30|EnergyPowder
31|Energy Root
32|Heal Powder
33|Revival Herb
34|Ether
35|Max Ether
36|Elixir
37|Max Elixir
38|Lava Cookie
39|Blue Flute
40|Yellow Flute
41|Red Flute
42|Black Flute
43|White Flute
44|Berry Juice
45|Sacred Ash
46|Shoal Salt
47|Shoal Shell
48|Red Shard
49|Blue Shard
50|Yellow Shard
51|Green Shard
63|HP Up
64|Protein
65|Iron
66|Carbos
67|Calcium
68|Rare Candy
69|PP Up
70|Zinc
71|PP Max
73|Guard Spec.
74|Dire Hit
75|X Attack
76|X Defend
77|X Speed
78|X Accuracy
79|X Special
80|Poké Doll
81|Fluffy Tail
83|Super Repel
84|Max Repel
85|Escape Rope
86|Repel
93|Sun Stone
94|Moon Stone
95|Fire Stone
96|Thunderstone
97|Water Stone
98|Leaf Stone
103|TinyMushroom
104|Big Mushroom
106|Pearl
107|Big Pearl
108|Stardust
109|Star Piece
110|Nugget
111|Heart Scale
121|Orange Mail
122|Harbor Mail
123|Glitter Mail
124|Mech Mail
125|Wood Mail
126|Wave Mail
127|Bead Mail
128|Shadow Mail
129|Tropic Mail
130|Dream Mail
131|Fab Mail
132|Retro Mail
133|Cheri Berry
134|Chesto Berry
135|Pecha Berry
136|Rawst Berry
137|Aspear Berry
138|Leppa Berry
139|Oran Berry
140|Persim Berry
141|Lum Berry
142|Sitrus Berry
143|Figy Berry
144|Wiki Berry
145|Mago Berry
146|Aguav Berry
147|Iapapa Berry
148|Razz Berry
149|Bluk Berry
150|Nanab Berry
151|Wepear Berry
152|Pinap Berry
153|Pomeg Berry
154|Kelpsy Berry
155|Qualot Berry
156|Hondew Berry
157|Grepa Berry
158|Tamato Berry
159|Cornn Berry
160|Magost Berry
161|Rabuta Berry
162|Nomel Berry
163|Spelon Berry
164|Pamtre Berry
165|Watmel Berry
166|Durin Berry
167|Belue Berry
168|Liechi Berry
169|Ganlon Berry
170|Salac Berry
171|Petaya Berry
172|Apicot Berry
173|Lansat Berry
174|Starf Berry
175|Enigma Berry
179|BrightPowder
180|White Herb
181|Macho Brace
182|Exp. Share
183|Quick Claw
184|Soothe Bell
185|Mental Herb
186|Choice Band
187|King's Rock
188|SilverPowder
189|Amulet Coin
190|Cleanse Tag
191|Soul Dew
192|DeepSeaTooth
193|DeepSeaScale
194|Smoke Ball
195|Everstone
196|Focus Band
197|Lucky Egg
198|Scope Lens
199|Metal Coat
200|Leftovers
201|Dragon Scale
202|Light Ball
203|Soft Sand
204|Hard Stone
205|Miracle Seed
206|BlackGlasses
207|Black Belt
208|Magnet
209|Mystic Water
210|Sharp Beak
211|Poison Barb
212|NeverMeltIce
213|Spell Tag
214|TwistedSpoon
215|Charcoal
216|Dragon Fang
217|Silk Scarf
218|Up-Grade
219|Shell Bell
220|Sea Incense
221|Lax Incense
222|Lucky Punch
223|Metal Powder
224|Thick Club
225|Stick
254|Red Scarf
255|Blue Scarf
256|Pink Scarf
257|Green Scarf
258|Yellow Scarf
259|Mach Bike
260|Coin Case
261|Itemfinder
262|Old Rod
263|Good Rod
264|Super Rod
265|S.S. Ticket
266|Contest Pass
268|Wailmer Pail
269|Devon Goods
270|Soot Sack
271|Basement Key
272|Acro Bike
273|Pokéblock Case
274|Letter
275|Eon Ticket
276|Red Orb
277|Blue Orb
278|Scanner
279|Go-Goggles
280|Meteorite
281|Rm. 1 Key
282|Rm. 2 Key
283|Rm. 4 Key
284|Rm. 6 Key
285|Storage Key
286|Root Fossil
287|Claw Fossil
288|Devon Scope
""".trimIndent()

private val ITEM_NAMES: Map<Int, String> = ITEM_DATA.lines().associate { line ->
    val parts = line.split('|', limit = 2)
    parts[0].toInt() to parts[1]
}.toMutableMap().apply {
    (289..338).forEach { put(it, "TM%02d".format(it - 288)) }
    (339..346).forEach { put(it, "HM%02d".format(it - 338)) }
    putAll(mapOf(
        349 to "Oak's Parcel", 350 to "Poké Flute", 351 to "Secret Key",
        352 to "Bike Voucher", 353 to "Gold Teeth", 354 to "Old Amber",
        355 to "Card Key", 356 to "Lift Key", 357 to "Helix Fossil",
        358 to "Dome Fossil", 359 to "Silph Scope", 360 to "Bicycle",
        361 to "Town Map", 362 to "VS Seeker", 363 to "Fame Checker",
        364 to "TM Case", 365 to "Berry Pouch", 366 to "Teachy TV",
        367 to "Tri-Pass", 368 to "Rainbow Pass", 369 to "Tea",
        370 to "MysticTicket", 371 to "AuroraTicket", 372 to "Powder Jar",
        373 to "Ruby", 374 to "Sapphire", 375 to "Magma Emblem", 376 to "Old Sea Map"
    ))
}

val SPECIES: List<String> = listOf("-") + G1.split(",") + G2.split(",") + List(25) { "?" } + HOENN.split(",")
val MOVES: List<String> = listOf("-") + MV.split(",")

fun speciesName(id: Int) = SPECIES.getOrNull(id) ?: "#$id"
fun moveName(id: Int) = MOVES.getOrNull(id) ?: "#$id"
fun itemName(id: Int): String = when (id) {
    0 -> "-"
    else -> ITEM_NAMES[id] ?: "Unused item (#$id)"
}

/** All named Generation III items, excluding unused index values. */
fun allItemChoices(): List<Pair<Int, String>> =
    listOf(0 to "-") + ITEM_NAMES.toList().sortedBy { it.first }
