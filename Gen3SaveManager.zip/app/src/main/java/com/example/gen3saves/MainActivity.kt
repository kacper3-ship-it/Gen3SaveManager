package com.example.gen3saves

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface { App() } } }
    }
}

private fun dir(ctx: android.content.Context) = File(ctx.filesDir, "saves").apply { mkdirs() }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val ctx = LocalContext.current
    var files by remember { mutableStateOf(dir(ctx).listFiles()?.sortedByDescending { it.lastModified() } ?: emptyList()) }
    var pendingExport by remember { mutableStateOf<File?>(null) }
    var renaming by remember { mutableStateOf<File?>(null) }
    fun refresh() { files = dir(ctx).listFiles()?.sortedByDescending { it.lastModified() } ?: emptyList() }
    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_LONG).show()

    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri ?: return@rememberLauncherForActivityResult
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return@rememberLauncherForActivityResult
        val info = Gen3.parse(bytes)
        if (info == null) { toast("Not a valid Gen 3 save (.sav, 128KB)"); return@rememberLauncherForActivityResult }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        File(dir(ctx), "${info.name.ifBlank { "SAVE" }}_${info.game.take(3).trim()}_$stamp.sav").writeBytes(bytes.copyOf(bytes.size))
        refresh()
    }
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri: Uri? ->
        val f = pendingExport
        if (uri != null && f != null) {
            ctx.contentResolver.openOutputStream(uri)?.use { it.write(f.readBytes()) }
            toast("Exported")
        }
        pendingExport = null
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Gen 3 Save Manager") }) },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = { importer.launch(arrayOf("*/*")) }, icon = { Icon(Icons.Default.Add, null) }, text = { Text("Import .sav") })
        }
    ) { pad ->
        if (files.isEmpty()) {
            Box(Modifier.padding(pad).fillMaxSize(), Alignment.Center) { Text("No saves yet. Import a .sav from Ruby, Sapphire, Emerald, FireRed or LeafGreen.") }
        } else LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(files, key = { it.name }) { f ->
                val info = remember(f.lastModified(), f.name) { Gen3.parse(f.readBytes()) }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Text(info?.game ?: "Unreadable", style = MaterialTheme.typography.labelLarge)
                        Text(info?.name ?: f.name, style = MaterialTheme.typography.headlineSmall)
                        if (info != null) {
                            Text("ID %05d / SID %05d · ${info.gender}".format(info.tid, info.sid))
                            Text("Play time ${info.playTime} · ₽${info.money}")
                            Text("Slot ${info.slot} · save #${info.saveCount}" + if (info.badSections > 0) " · ⚠ ${info.badSections} bad checksums" else " · checksums OK")
                        }
                        Text(f.name, style = MaterialTheme.typography.bodySmall)
                        Row {
                            IconButton({ pendingExport = f; exporter.launch(f.name) }) { Icon(Icons.Default.Share, "Export") }
                            IconButton({ f.copyTo(File(f.parentFile, "copy_${System.currentTimeMillis()}_${f.name}")); refresh() }) { Icon(Icons.Default.ContentCopy, "Duplicate") }
                            IconButton({ renaming = f }) { Icon(Icons.Default.Edit, "Rename") }
                            IconButton({ f.delete(); refresh() }) { Icon(Icons.Default.Delete, "Delete") }
                        }
                    }
                }
            }
        }
    }

    renaming?.let { f ->
        var text by remember { mutableStateOf(f.nameWithoutExtension) }
        AlertDialog(onDismissRequest = { renaming = null },
            title = { Text("Rename save") },
            text = { OutlinedTextField(text, { text = it }, singleLine = true) },
            confirmButton = { TextButton({ f.renameTo(File(f.parentFile, text.trim().replace('/', '_') + ".sav")); renaming = null; refresh() }) { Text("OK") } },
            dismissButton = { TextButton({ renaming = null }) { Text("Cancel") } })
    }
}
