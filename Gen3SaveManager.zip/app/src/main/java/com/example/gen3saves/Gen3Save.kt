package com.example.gen3saves

fun u8(b: ByteArray, o: Int) = b[o].toInt() and 0xFF
fun u16(b: ByteArray, o: Int) = u8(b, o) or (u8(b, o + 1) shl 8)
fun u32(b: ByteArray, o: Int) = u16(b, o).toLong() or (u16(b, o + 2).toLong() shl 16)
fun p16(b: ByteArray, o: Int, v: Int) { b[o] = v.toByte(); b[o + 1] = (v shr 8).toByte() }
fun p32(b: ByteArray, o: Int, v: Long) { p16(b, o, (v and 0xFFFF).toInt()); p16(b, o + 2, ((v shr 16) and 0xFFFF).toInt()) }

fun decodeText(b: ByteArray, off: Int, max: Int): String {
    val sb = StringBuilder()
    for (i in 0 until max) {
        val c = u8(b, off + i)
        when (c) {
            0xFF -> break
            0x00 -> sb.append(' ')
            in 0xA1..0xAA -> sb.append('0' + (c - 0xA1))
            in 0xBB..0xD4 -> sb.append('A' + (c - 0xBB))
            in 0xD5..0xEE -> sb.append('a' + (c - 0xD5))
            0xAB -> sb.append('!')
            0xAC -> sb.append('?')
            0xAD -> sb.append('.')
            0xAE -> sb.append('-')
            else -> sb.append('?')
        }
    }
    return sb.toString()
}


fun encodeGen3Text(value: String, max: Int): ByteArray {
    val out = ByteArray(max) { 0xFF.toByte() }
    var i = 0
    for (ch in value) {
        if (i >= max - 1) break
        val code = when (ch) {
            ' ' -> 0x00
            in '0'..'9' -> 0xA1 + (ch - '0')
            in 'A'..'Z' -> 0xBB + (ch - 'A')
            in 'a'..'z' -> 0xD5 + (ch - 'a')
            '!' -> 0xAB; '?' -> 0xAC; '.' -> 0xAD; '-' -> 0xAE
            ',' -> 0xB8; '\'' -> 0xB4; '"' -> 0xB5; ':' -> 0xF0
            else -> 0xAC
        }
        out[i++] = code.toByte()
    }
    if (i < max) out[i] = 0xFF.toByte()
    return out
}

data class SaveInfo(
    val game: String, val name: String, val gender: String, val tid: Int, val sid: Int,
    val playTime: String, val money: Long, val slot: Char, val saveCount: Long, val badSections: Int
)

class Pocket(val name: String, val off: Int, val n: Int)
class Layout(val money: Int, val party: Int, val pockets: List<Pocket>)

/** A Generation 3 (RSE/FRLG) 128KB save. Edits go straight into [data]; call fixChecksums() before writing. */
class Save private constructor(val data: ByteArray, private val sec: IntArray, val slot: Int, val count: Long) {
    private val code = u32(data, sec[0] + 0xAC)
    val game = when (code) { 0L -> 0; 1L -> 1; else -> 2 } // 0 RS, 1 FRLG, 2 Emerald
    val gameName = listOf("Ruby / Sapphire", "FireRed / LeafGreen", "Emerald")[game]
    private val key: Long = when (game) { 0 -> 0L; 1 -> u32(data, sec[0] + 0xAF8); else -> code }
    private val k16 = (key and 0xFFFF).toInt()

    val layout: Layout = when (game) {
        0 -> Layout(0x490, 0x234, listOf(Pocket("PC items", 0x498, 50), Pocket("Items", 0x560, 20), Pocket("Key items", 0x5B0, 20),
            Pocket("Poké Balls", 0x600, 16), Pocket("TMs & HMs", 0x640, 64), Pocket("Berries", 0x740, 46)))
        1 -> Layout(0x290, 0x34, listOf(Pocket("PC items", 0x298, 30), Pocket("Items", 0x310, 42), Pocket("Key items", 0x3B8, 30),
            Pocket("Poké Balls", 0x430, 13), Pocket("TMs & HMs", 0x464, 58), Pocket("Berries", 0x54C, 43)))
        else -> Layout(0x490, 0x234, listOf(Pocket("PC items", 0x498, 50), Pocket("Items", 0x560, 30), Pocket("Key items", 0x5D8, 30),
            Pocket("Poké Balls", 0x650, 16), Pocket("TMs & HMs", 0x690, 64), Pocket("Berries", 0x790, 46)))
    }

    var money: Long
        get() = (u32(data, sec[1] + layout.money) xor key) and 0xFFFFFFFFL
        set(v) = p32(data, sec[1] + layout.money, v xor key)

    val partyCount get() = u8(data, sec[1] + layout.party).coerceIn(0, 6)
    private fun partyAddr(i: Int) = sec[1] + layout.party + 4 + i * 100
    fun getParty(i: Int) = data.copyOfRange(partyAddr(i), partyAddr(i) + 100)
    fun setParty(i: Int, raw: ByteArray) = raw.copyInto(data, partyAddr(i))

    // PC buffer is spread over sections 5..13 (3968 bytes each, last one shorter)
    private fun pc(l: Int) = sec[5 + l / 3968] + l % 3968
    val currentBox get() = u8(data, pc(0))
    fun getBox(b: Int, i: Int): ByteArray { val s = 4 + (b * 30 + i) * 80; return ByteArray(80) { data[pc(s + it)] } }
    fun setBox(b: Int, i: Int, raw: ByteArray) { val s = 4 + (b * 30 + i) * 80; for (k in 0 until 80) data[pc(s + k)] = raw[k] }
    fun boxName(b: Int): String { val t = ByteArray(9) { data[pc(33604 + b * 9 + it)] }; return decodeText(t, 0, 9).ifBlank { "BOX ${b + 1}" } }

    fun getItem(p: Pocket, i: Int): Pair<Int, Int> {
        val o = sec[1] + p.off + i * 4
        return u16(data, o) to (u16(data, o + 2) xor k16)
    }
    fun setItem(p: Pocket, i: Int, id: Int, qty: Int) {
        val o = sec[1] + p.off + i * 4
        p16(data, o, id); p16(data, o + 2, qty xor k16)
    }

    private fun nationalDex(species: Int): Int = when (species) { in 1..251 -> species; in 277..411 -> species - 25; else -> 0 }
    private fun block1Byte(offset: Int): Int = sec[1 + offset / 3968] + offset % 3968
    private fun bitAt(offset: Int, dex: Int): Boolean {
        val n = dex - 1
        return (u8(data, offset + n / 8) and (1 shl (n % 8))) != 0
    }
    private fun setBitAt(offset: Int, dex: Int, value: Boolean) {
        val n = dex - 1; val at = offset + n / 8; val mask = 1 shl (n % 8)
        val old = u8(data, at)
        data[at] = (if (value) old or mask else old and mask.inv()).toByte()
    }
    fun dexSeen(species: Int): Boolean {
        if (game != 1) return false
        val dex = nationalDex(species); if (dex == 0) return false
        return bitAt(sec[0] + 0x5C, dex)
    }
    fun dexCaught(species: Int): Boolean {
        if (game != 1) return false
        val dex = nationalDex(species); if (dex == 0) return false
        return bitAt(sec[0] + 0x28, dex)
    }
    fun setDexFlags(species: Int, seen: Boolean, caught: Boolean) {
        if (game != 1) return
        val dex = nationalDex(species); if (dex == 0) return
        setBitAt(sec[0] + 0x5C, dex, seen || caught)
        setBitAt(sec[0] + 0x28, dex, caught)
        // FireRed keeps two anti-cheat copies of the seen flags in SaveBlock1.
        setBitAt(block1Byte(0x5F8), dex, seen || caught)
        setBitAt(block1Byte(0x3A18), dex, seen || caught)
    }

    fun fixChecksums() { for (i in 0..13) p16(data, sec[i] + 0xFF6, checksum(data, sec[i], SIZES[i])) }

    fun info(): SaveInfo {
        val t = sec[0]
        val bad = (0..13).count { checksum(data, sec[it], SIZES[it]) != u16(data, sec[it] + 0xFF6) }
        val time = "${u16(data, t + 0x0E)}:%02d:%02d".format(u8(data, t + 0x10), u8(data, t + 0x11))
        return SaveInfo(gameName, decodeText(data, t, 7), if (u8(data, t + 8) == 0) "Boy" else "Girl",
            u16(data, t + 0x0A), u16(data, t + 0x0C), time, money, if (slot == 0) 'A' else 'B', count, bad)
    }

    companion object {
        const val SIZE = 131072
        private const val SEC = 4096
        private val SIZES = intArrayOf(3884, 3968, 3968, 3968, 3848, 3968, 3968, 3968, 3968, 3968, 3968, 3968, 3968, 2000)

        private fun checksum(b: ByteArray, off: Int, len: Int): Int {
            var sum = 0L
            for (i in 0 until len step 4) sum = (sum + u32(b, off + i)) and 0xFFFFFFFFL
            return (((sum shr 16) + (sum and 0xFFFF)) and 0xFFFF).toInt()
        }

        fun open(d: ByteArray): Save? {
            if (d.size < SIZE) return null
            val offs = Array(2) { IntArray(14) { -1 } }
            val idx = LongArray(2) { -1 }
            for (slot in 0..1) for (s in 0 until 14) {
                val o = slot * 14 * SEC + s * SEC
                if (u32(d, o + 0xFF8) != 0x08012025L) continue
                val id = u16(d, o + 0xFF4)
                if (id > 13) continue
                offs[slot][id] = o
                idx[slot] = maxOf(idx[slot], u32(d, o + 0xFFC))
            }
            var best = -1
            for (slot in 0..1) if (offs[slot].all { it >= 0 } && (best < 0 || idx[slot] > idx[best])) best = slot
            if (best < 0) return null
            return Save(d.copyOf(), offs[best], best, idx[best])
        }
    }
}

private val ORDERS = arrayOf("GAEM", "GAME", "GEAM", "GEMA", "GMAE", "GMEA", "AGEM", "AGME", "AEGM", "AEMG", "AMGE", "AMEG",
    "EGAM", "EGMA", "EAGM", "EAMG", "EMGA", "EMAG", "MGAE", "MGEA", "MAGE", "MAEG", "MEGA", "MEAG")
private val NATURES = "Hardy,Lonely,Brave,Adamant,Naughty,Bold,Docile,Relaxed,Impish,Lax,Timid,Hasty,Serious,Jolly,Naive,Modest,Mild,Quiet,Bashful,Rash,Calm,Gentle,Sassy,Careful,Quirky".split(",")

/** One Pokémon (80-byte box or 100-byte party format). Substructures are decrypted into [d]. */
class Mon(src: ByteArray) {
    val raw = src.copyOf()
    private val d = ByteArray(48)
    private var pid = u32(raw, 0)
    private val otid = u32(raw, 4)
    private var order = ORDERS[(pid % 24).toInt()]
    init { for (i in 0 until 12) p32(d, i * 4, u32(raw, 0x20 + i * 4) xor (pid xor otid)) }
    private fun b(c: Char) = order.indexOf(c) * 12

    var species: Int get() = u16(d, b('G')); set(v) = p16(d, b('G'), v)
    var item: Int get() = u16(d, b('G') + 2); set(v) = p16(d, b('G') + 2, v)
    fun move(i: Int) = u16(d, b('A') + i * 2)
    fun setMove(i: Int, v: Int) { p16(d, b('A') + i * 2, v); d[b('A') + 8 + i] = if (v == 0) 0 else 5 }
    fun ev(i: Int) = u8(d, b('E') + i)
    fun setEv(i: Int, v: Int) { d[b('E') + i] = v.toByte() }
    fun iv(i: Int) = ((u32(d, b('M') + 4) shr (5 * i)) and 31).toInt()
    fun setIv(i: Int, v: Int) {
        val x = u32(d, b('M') + 4)
        p32(d, b('M') + 4, (x and (31L shl (5 * i)).inv()) or (v.toLong() shl (5 * i)))
    }
    val isEgg get() = ((u32(d, b('M') + 4) shr 30) and 1L) == 1L
    var nick: String
        get() = decodeText(raw, 8, 10).trim()
        set(value) { encodeGen3Text(value, 10).copyInto(raw, 8) }
    val level get() = u8(raw, 0x54)
    val checksumValid: Boolean get() {
        var sum = 0
        for (i in 0 until 24) sum = (sum + u16(d, i * 2)) and 0xFFFF
        return sum == u16(raw, 0x1C)
    }
    val nature get() = NATURES[(pid % 25).toInt()]
    val abilitySlot get() = (pid and 1L).toInt() // Gen III selects one of the species' two ability slots from PID bit 0.

    /** Changes PID while retaining the current shiny/non-shiny state and requested ability slot. */
    fun setNatureAndAbility(natureName: String, slot: Int): Boolean {
        val wantedNature = NATURES.indexOf(natureName)
        if (wantedNature < 0 || slot !in 0..1) return false
        if (nature == natureName && abilitySlot == slot) return true
        val wasShiny = shiny
        val start = (pid + 1L) and 0xFFFFFFFFL
        // PID controls nature, ability slot and shininess. Keep shininess stable while
        // finding a personality value with the requested nature and ability slot.
        for (step in 0L..2_000_000L) {
            val candidate = (start + step) and 0xFFFFFFFFL
            if ((candidate % 25L).toInt() != wantedNature || (candidate and 1L).toInt() != slot) continue
            val tid = (otid and 0xFFFF).toInt()
            val sid = (otid shr 16).toInt()
            val shinyValue = tid xor sid xor (candidate shr 16).toInt() xor (candidate and 0xFFFF).toInt()
            val candidateShiny = shinyValue < 8
            if (candidateShiny == wasShiny) {
                // Reorder the decrypted substructures because PID % 24 also selects
                // their physical order in the encrypted record.
                val canonical = ByteArray(48)
                for (letter in charArrayOf('A', 'G', 'E', 'M')) {
                    val canonicalOffset = when (letter) { 'A' -> 0; 'G' -> 12; 'E' -> 24; else -> 36 }
                    d.copyOfRange(b(letter), b(letter) + 12).copyInto(canonical, canonicalOffset)
                }
                pid = candidate
                order = ORDERS[(pid % 24).toInt()]
                for (letter in charArrayOf('A', 'G', 'E', 'M')) {
                    val canonicalOffset = when (letter) { 'A' -> 0; 'G' -> 12; 'E' -> 24; else -> 36 }
                    canonical.copyOfRange(canonicalOffset, canonicalOffset + 12).copyInto(d, b(letter))
                }
                return true
            }
        }
        return false
    }
    val shiny: Boolean get() {
        val tid = (otid and 0xFFFF).toInt(); val sid = (otid shr 16).toInt()
        return (tid xor sid xor (pid shr 16).toInt() xor (pid and 0xFFFF).toInt()) < 8
    }

    fun toRaw(): ByteArray {
        val out = raw.copyOf()
        p32(out, 0, pid)
        var cs = 0
        for (i in 0 until 24) cs += u16(d, i * 2)
        p16(out, 0x1C, cs and 0xFFFF)
        for (i in 0 until 12) p32(out, 0x20 + i * 4, u32(d, i * 4) xor (pid xor otid))
        return out
    }
}
