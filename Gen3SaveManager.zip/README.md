# Gen 3 Save Manager – FireRed Edition

Android Kotlin/Jetpack Compose project. Open this folder as the Gradle project root or place its contents in the directory your GitHub Actions workflow runs Gradle from.

## Current features
- Gen III save loading and checksum refresh
- Trainer details and money editing
- Party and PC Pokémon editor
- 14 PC boxes with 30 slots each, search, cross-box search, duplicate, release and move between boxes
- Bag item editing and item picker
- Basic PC Pokémon creation
- Import/export of 80-byte Gen III `.pk3` records
- FireRed/LeafGreen Pokédex seen/caught editor
- Nature and ability-slot selection in the Pokémon editor (personality value is adjusted while retaining shiny status)
- Pokémon front sprites loaded from PokeAPI's public sprite repository when online; a ball placeholder is shown offline
- First-open original save backup

## Safety notes
Keep a separate backup of every save before editing. The app currently does not implement full party stat recalculation, ROM-derived ability names/base stats, event/Wonder Card injection, or a complete legal Pokémon generator. Nature/ability-slot changes adjust the personality value; this can affect PID-dependent properties such as gender or Unown form. Verify edited Pokémon in-game before relying on them.

Pokédex editing is currently enabled only for FireRed/LeafGreen. Other Gen III variants show an explanatory message rather than writing unverified offsets.
